//
//  CustomLabel.swift
//  BeBettaApp
//
//  Created by Tejashree on 25/01/24.
//

import Foundation
import UIKit

class CustomLabel: UILabel {
    
    @IBInspectable var cornerRadius:CGFloat = 0
    @IBInspectable var borderWidth:CGFloat = 0
    @IBInspectable var borderColour:UIColor = UIColor.clear
    @IBInspectable var shadowColour:UIColor = UIColor.clear
    @IBInspectable var shadowOffsetY:CGFloat = 1
    @IBInspectable var shadowOffsetX:CGFloat = 0
    @IBInspectable var shadowOpacity:Float = 1
    @IBInspectable var shadowRadius:CGFloat = 2
    @IBInspectable var letterSapcing:CGFloat = 0.5
    @IBInspectable var lineHeight:CGFloat = 10
    @IBInspectable var lineHeightMultiple:CGFloat = 0.9
    @IBInspectable var baseline:CGFloat = -1
    @IBInspectable var applyLineHeight:Bool = false
    @IBInspectable var applyLetterSpacing:Bool = false
    
    override var text: String? {
        didSet {
            if text != nil {
                
                applyAttributes()
                
            }
        }
    }
    
    private func applyAttributes()
    {
        if applyLetterSpacing
        {
            let attributedString = NSMutableAttributedString(string: text!)
            
            attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: textColor!, range: NSRange(location:0,length:(text?.length)!))
            attributedString.addAttribute(NSAttributedString.Key.font, value: font!, range: NSRange(location:0,length:(text?.length)!))
            attributedString.addAttribute(NSAttributedString.Key.kern, value: letterSapcing, range: NSRange(location: 0, length: attributedString.length))
            
            attributedString.addAttribute(NSAttributedString.Key.baselineOffset,value: baseline, range: NSRange(location: 0, length: attributedString.length))
            
            attributedText = attributedString
        }
        
        
        if applyLineHeight
        {
            
            
            let style = NSMutableParagraphStyle()
            style.lineSpacing = lineHeight
            style.lineHeightMultiple = lineHeightMultiple
            style.alignment = textAlignment
            
            if (attributedText?.length)! > 0
            {
                let attributedString = NSMutableAttributedString(attributedString: attributedText!)
                attributedString.addAttribute(NSAttributedString.Key.paragraphStyle, value: style, range: NSRange(location: 0, length: attributedString.length))
                
                attributedText = attributedString
            }else
            {
                let attributedString = NSMutableAttributedString(string: text!)
                
                attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: textColor!, range: NSRange(location:0,length:(text?.length)!))
                attributedString.addAttribute(NSAttributedString.Key.font, value: font!, range: NSRange(location:0,length:(text?.length)!))
                attributedString.addAttribute(NSAttributedString.Key.paragraphStyle, value: style, range: NSRange(location: 0, length: attributedString.length))
                attributedString.addAttribute(NSAttributedString.Key.baselineOffset,value: baseline, range: NSRange(location: 0, length: attributedString.length))
                attributedText = attributedString
            }
            
        }
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        applyAttributes()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.borderColor = borderColour.cgColor
        self.layer.borderWidth = borderWidth
        self.layer.cornerRadius = cornerRadius
        self.layer.shadowColor = shadowColour.cgColor;
        self.layer.shadowOffset = CGSize(width: shadowOffsetX, height: shadowOffsetY)
        self.layer.shadowOpacity = shadowOpacity
        self.layer.shadowRadius = shadowRadius
        self.clipsToBounds = true
    }
}

extension String {
    var length : Int {
        return self.count
    }
}

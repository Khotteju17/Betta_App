//
//  FilterCollectionViewCell.swift
//  AppEmpressa
//
//  Created by Bhagyashree Khot on 17/12/20.
//

import UIKit

class SportsCell: UICollectionViewCell {
    static let reuseidentifier = "SportsCell"
   
    var selection = Int()
    @IBOutlet weak var label : CustomLabel!
    @IBOutlet weak var imageView : UIImageView!
    @IBOutlet weak var buttonCell : UIButton!
    
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
}



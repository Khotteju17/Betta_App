//
//  Cells.swift
//  BeBettaApp
//
//  Created by Tejashree on 25/01/24.
//

import UIKit

class Sports: UICollectionViewCell {
    static var reuseidentifier = "Sports"
    
    @IBOutlet weak var label : UILabel!
    @IBOutlet weak var imageV : UIImageView!
    
}

class AddSports : UICollectionViewCell{
    static var reuseidentifier = "AddSports"
    
    @IBOutlet weak var imageView : UIImageView!
    @IBOutlet weak var imageViewLogo : UIImageView!
}

class Matches : UICollectionViewCell{
    static var reuseidentifier = "Matches"
    
    @IBOutlet weak var name1 : UILabel!
    @IBOutlet weak var name2 : UILabel!
    @IBOutlet weak var image1 : UIImageView!
    @IBOutlet weak var image2 : UIImageView!
    @IBOutlet weak var labelTime : UILabel!
    @IBOutlet weak var score1 : UILabel!
    @IBOutlet weak var score2 : UILabel!
}

class Player : UICollectionViewCell{
    static var reuseidentifier = "Player"
    
    @IBOutlet weak var playerName : UILabel!
    @IBOutlet weak var playerImage : UIImageView!
}

//
//  ViewController.swift
//  BeBettaApp
//
//  Created by Tejashree on 25/01/24.
//

import UIKit

class DashboardViewController: UIViewController {
    static var identifier = "DashboardViewController"
    
    @IBOutlet weak var collectionViewSports: UICollectionView!
    @IBOutlet weak var collectionViewLive: UICollectionView!
    @IBOutlet weak var collectionViewPlayers: UICollectionView!
    @IBOutlet weak var collectionViewPreview: UICollectionView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var animateView: UIView!
    @IBOutlet weak var animateImage1 : UIImageView!
    @IBOutlet weak var animateImage2 : UIImageView!
    @IBOutlet weak var liveLabel: UILabel!
    
    var titleArray = ["Football", "Cricket", "Add"]
    var playerArray = ["USAB", "DAL","NCAAF", "Madrid", "PHI"]
    var previewArray = ["preview1", "preview2"]
    var selectedIndex = 0
    var score: [Score] = []
    let collectionMargin = CGFloat(16)
    let itemSpacing = CGFloat(10)
    let itemHeight = CGFloat(132)
    var itemWidth = CGFloat(0)
    
    // MARK: - View Controller methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.decodeApexPredatorsData()
        collectionViewPlayers.reloadData()
        liveLabel.layer.cornerRadius = 4
        liveLabel.layer.masksToBounds = true
        
    }
    // MARK: - IBActions
    
    @IBAction func home(_ sender: Any) {
        animateView.isHidden = true
        
    }
    
    @IBAction func showRewardView(_ sender: Any) {
        animateView.isHidden = false
        
        moveIt(animateImage1, 7)
        moveItReverse(animateImage2, 7)
    }
    
    func decodeApexPredatorsData(){
        // Checking whether file is there
        if let url = Bundle.main.url(forResource: "data", withExtension: "json"){
            // to make language error free do try catch
            do{
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                score = try decoder.decode([Score].self, from: data)
            } catch {
                print("Error decoding json : \(error)")
            }
        }
        self.collectionViewSports.reloadData()
        self.collectionViewLive.reloadData()
        self.collectionViewPreview.reloadData()
    }
    
    func moveIt(_ imageView: UIImageView,_ speed:CGFloat) {
        let speeds = speed
        let imageSpeed = speeds / view.frame.size.width
        let averageSpeed = (view.frame.size.width - imageView.frame.origin.x) * imageSpeed
        UIView.animate(withDuration: TimeInterval(averageSpeed), delay: 0.0, options: .curveLinear, animations: {
            imageView.frame.origin.x = self.view.frame.size.width
        }, completion: { (_) in
            imageView.frame.origin.x = -imageView.frame.size.width
            self.moveIt(imageView,speeds)
        })
    }
    
    func moveItReverse(_ imageView: UIImageView,_ speed:CGFloat) {
        let speeds = speed
        let imageSpeed = speeds / view.frame.size.width
        let averageSpeed = (view.frame.size.width - imageView.frame.origin.x) * imageSpeed
        UIView.animate(withDuration: TimeInterval(averageSpeed), delay: 0.0, options: .curveLinear, animations: {
            imageView.frame.origin.x = -self.view.frame.size.width
        }, completion: { (_) in
            imageView.frame.origin.x = -imageView.frame.size.width
            self.moveIt(imageView,speeds)
        })
    }
}

// MARK: - Extensions with CollectionView Delegate, Datasource methods

extension DashboardViewController : UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView.tag == 100{
            return 2
        }else if collectionView.tag == 200{
            return playerArray.count
        }else if collectionView.tag == 300{
            return previewArray.count
        }
        
        return titleArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView.tag == 100{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Matches", for: indexPath) as! Matches
            
            let scoreData = score[indexPath.row]
            print("scoreData.name1.description",scoreData.name1.description)
            cell.name1.text = scoreData.name1.description
            cell.name2.text = scoreData.name2.description
            cell.score1.text = scoreData.score1.description
            cell.score2.text = scoreData.score2.description
            cell.labelTime.text = scoreData.time.description
            cell.image1.image = UIImage(named: scoreData.name1)
            cell.image2.image = UIImage(named: scoreData.name2)
            if indexPath.row % 2 == 0{
                cell.layer.borderColor = UIColor.lightGray.withAlphaComponent(0.5).cgColor
                cell.layer.borderWidth = 2
                cell.layer.cornerRadius = 10
                cell.labelTime.textColor = UIColor.init(red: 0.96, green: 0.73, blue: 0.25, alpha: 1.00)
            }else{
                cell.layer.borderColor = UIColor.darkGray.withAlphaComponent(0.5).cgColor
                cell.layer.borderWidth = 2
                cell.layer.cornerRadius = 10
                cell.labelTime.textColor = UIColor.init(red: 0.38, green: 0.74, blue: 0.35, alpha: 1.00)
            }
            return cell
        }else if collectionView.tag == 200{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Player", for: indexPath) as! Player
            
            cell.playerImage.image = UIImage.init(named: playerArray[indexPath.row])
            cell.playerName.text = playerArray[indexPath.row]
            return cell
        }else if collectionView.tag == 300{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddSports", for: indexPath) as! AddSports
            
            cell.imageView.image = UIImage.init(named: previewArray[indexPath.row])
            if indexPath.row == 0{
                cell.imageViewLogo.image = UIImage.init(named: "logo1")
            }else{
                cell.imageViewLogo.image = UIImage.init(named: "logo2")
            }
            cell.layer.cornerRadius = 10
            return cell
        }else{
            if indexPath.row == 2{
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: AddSports.reuseidentifier, for: indexPath) as! AddSports
                cell.imageView.image = UIImage(named: "Adding_button")
                cell.layer.cornerRadius = 17
                return cell
            }else{
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: AddSports.reuseidentifier, for: indexPath) as! AddSports
                let title = self.titleArray[indexPath.row]
                cell.imageView.image = UIImage(named: title)
                cell.imageView.layer.cornerRadius = 18
                if indexPath.row % 2 == 0{
                    cell.imageView.layer.borderColor = UIColor.white.withAlphaComponent(0.5).cgColor
                    cell.imageView.layer.borderWidth = 1
                }else{
                    cell.imageView.layer.borderColor = UIColor.lightGray.withAlphaComponent(0.5).cgColor
                    cell.imageView.layer.borderWidth = 1
                }
                return cell
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView.tag == 100{
            return 12
        }else if collectionView.tag == 200{
            return 2
        }else if collectionView.tag == 600{
            return 6
        }
        
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView.tag == 100{
            return 16
        }else if collectionView.tag == 200{
            return 25
        }else if collectionView.tag == 600{
            return 6
        }
        return 12
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView.tag == 100{
            return CGSize(width: 172.0, height: 150.0)
        }else if collectionView.tag == 200{
            return CGSize(width: 60.0, height: 120.0)
        }else if collectionView.tag == 300{
            return CGSize(width: 250.0, height: 150.0)
        }else{
            if indexPath.row == 2{
                return CGSize(width: 175.0, height: 34.0)
            }
            return CGSize(width: 112.0, height: 34.0)
        }
        
    }
}

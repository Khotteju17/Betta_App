//
//  AppPredators.swift
//  JP Apex Predators
//
//  Created by Tejashree on 10/01/24.
//

import Foundation
import SwiftUI

struct Score: Codable, Identifiable{
    let id: String
    let name1: String
    let name2: String
    let score1: String
    let score2: String
    let time: String
}

